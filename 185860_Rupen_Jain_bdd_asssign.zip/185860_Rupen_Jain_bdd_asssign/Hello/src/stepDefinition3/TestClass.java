package stepDefinition3;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class TestClass {

	@Given("^User is trying to open Hello Page$")
	public void user_is_trying_to_open_Hello_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User is trying to open Hello Page");
	}

	@When("^User opens hello page$")
	public void user_opens_hello_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("User opens hello page");
	}

	@Then("^open hello page and dispaly Hello message$")
	public void open_hello_page_and_dispaly_Hello_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("open hello page and dispaly Hello message");
	}
}
